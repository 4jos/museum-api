import { atom } from 'jotai';


export const favouritesAtom = atom([]);
export const searchHistoryAtom = atom([]);


