import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
 import Nav from 'react-bootstrap/Nav';
 import Form from 'react-bootstrap/Form';
 import { useRouter } from 'next/router'
 import Link from 'next/link';

import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
 


function MainNav() {
  var router= useRouter();

  const [search, setSearch] = useState('');

  function submitForm(e) {
   // alert(`form submitted - userName: ${userName}`);
   router.push(`/artwork?title=true&q=${search}`);
    e.preventDefault(); // prevent the browser from automatically submitting the form


  }

  return (
    <>
 

    <Navbar bg="dark" variant="dark" expand="lg" className="fixed-top">
      <Container fluid>
        <Navbar.Brand href="#">Joshua Wong</Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll">
          <Nav
            className="me-auto my-2 my-lg-0"
            style={{ maxHeight: '100px' }}
            navbarScroll
          >
         <Nav.Link href="/">Home</Nav.Link>
           <Nav.Link href="/search">Advanced Search</Nav.Link>
          
          
          </Nav>
          <Form onSubmit={submitForm}  className="d-flex">
       <Form.Control               type="search"
className="me-2" value={search} placeholder="Search"
              aria-label="Search" onChange={(e) => setSearch(e.target.value)} />
     
      <Button variant="outline-success" type="submit">Search</Button>
    </Form>

    
        </Navbar.Collapse>
      </Container>
    </Navbar>
    </>

  );


}

export default MainNav;




